/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comicbook;

/**
 *
 * @author ZAAHEN
 */
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class ComicBookManagement {
    private static final String FILE_NAME = "ComicBooks.txt";
    private final ArrayList<ComicBooks> comicBooks = new ArrayList<>();
    private File dataFile; // resolved by user.dir

    public static void main(String[] args) throws ComicBookException {
        Locale.setDefault(Locale.US);
        new ComicBookManagement().run();
    }

    private void run() throws ComicBookException {
        resolveDataFile();
        ensureSampleFileIfMissing();   // auto-create 5 sample books if file missing
        loadFromFile();
        displayInventory();            // show list immediately

        Scanner sc = new Scanner(System.in);
        while (true) {
            printMenu();
            int choice = readInt(sc, "Please select a funtion: ", 1, 6);

            switch (choice) {
                case 1:
                    addComicBook(sc);
                    displayInventory();
                    break;
                case 2:
                    searchByTitle(sc);
                case 3:
                    searchByAuthor(sc);
                case 4:
                    updateRentalPrice(sc);
                    displayInventory();
                    break;
                case 5:
                    deleteById(sc);
                    displayInventory();
                    break;
                case 6:
                    saveToFile();
                    System.out.println("Saved to " + dataFile.getAbsolutePath() + ". Program exited.");
                    sc.close();
                    return;
            }
        }
    }

    private void resolveDataFile() {
        // NetBeans-friendly: uses current working directory (user.dir)
        String dir = System.getProperty("user.dir");
        dataFile = new File(dir, FILE_NAME);

        System.out.println("INFO: Working directory = " + dir);
        System.out.println("INFO: Data file path     = " + dataFile.getAbsolutePath());
    }

    private void ensureSampleFileIfMissing() {
        if (dataFile.exists()) return;

        System.out.println("INFO: " + FILE_NAME + " not found. Creating a sample file with 5 books...");

        try (BufferedWriter bw = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(dataFile), StandardCharsets.UTF_8))) {

            bw.write("1|One Piece|2.50|Eiichiro Oda|1"); bw.newLine();
            bw.write("2|Naruto|2.00|Masashi Kishimoto|5"); bw.newLine();
            bw.write("3|Detective Conan|1.80|Gosho Aoyama|10"); bw.newLine();
            bw.write("4|Dragon Ball|2.20|Akira Toriyama|3"); bw.newLine();
            bw.write("5|Attack on Titan|3.00|Hajime Isayama|2"); bw.newLine();

        } catch (Exception e) {
            System.out.println("WARNING: Failed to create sample file.");
        }
    }

    private void printMenu() {
        System.out.println("\n========== COMIC BOOK RENTAL MANAGEMENT ==========");
        System.out.println("1. Add new comic book.");
        System.out.println("2. Search book by title.");
        System.out.println("3. Search book of an author.");
        System.out.println("4. Update book rental price.");
        System.out.println("5. Delete comic book.");
        System.out.println("6. Quit");
        System.out.println("==================================================");
    }

    // 1) Add
    private void addComicBook(Scanner sc) {
        System.out.println("\n--- Add a New Comic Book ---");

        int id;
        while (true) {
            id = readInt(sc, "Enter ID (positive integer): ", 1, Integer.MAX_VALUE);
            if (findIndexById(id) != -1) {
                System.out.println("ERROR: ID already exists. Please enter a different ID.");
                continue;
            }
            break;
        }

        String title = readNonEmptyString(sc, "Enter title: ");
        String author = readNonEmptyString(sc, "Enter author: ");
        int volume = readInt(sc, "Enter volume (positive integer): ", 1, Integer.MAX_VALUE);

        double price;
        while (true) {
            price = readDouble(sc, "Enter rental price (USD, must be > 0): ");
            if (price <= 0) System.out.println("ERROR: Rental price must be greater than 0.");
            else break;
        }

        try {
            ComicBooks newBook = new ComicBooks(id, title, price, author, volume);

            // Duplicate content rule: same title+author+volume
            for (ComicBooks b : comicBooks) {
                if (b.isSameContent(newBook)) {
                    System.out.println("ERROR: Duplicate content (same title + author + volume). Not added.");
                    return;
                }
            }

            comicBooks.add(newBook);
            System.out.println("SUCCESS: Comic book added.");
        } catch (ComicBookException e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
    //2
 private void searchByTitle(Scanner sc) {
    System.out.println("\n--- Search Book By Title ---");

    if (comicBooks.isEmpty()) {
        System.out.println("Inventory is empty.");
        return;
    }

    String query;
    while (true) {
        System.out.print("Enter title keyword: ");
        query = sc.nextLine().trim();
        if (!query.isEmpty()) break;
        System.out.println("ERROR: Search keyword cannot be empty.");
    }

    query = query.toLowerCase();

    boolean found = false;

    String border = "+------+--------+---------------------------+--------------+----------------------+--------+";

    System.out.println("\n--- SEARCH RESULT ---");
    System.out.println(border);
System.out.printf("| %-4s | %-6s | %-25s | %-12s | %-20s | %-6s |%n",
            "No.", "ID", "Title", "RentalPrice", "Author", "Volume");
    System.out.println(border);

    int no = 1;

    for (ComicBooks b : comicBooks) {
        if (b.getTitle().toLowerCase().contains(query)) {

            System.out.printf("| %4d | %6d | %-25s | %10.2f $ | %-20s | %6d |%n",
                    no++,
                    b.getId(),
                    cut(b.getTitle(), 25),
                    b.getBookRentalPrice(),
                    cut(b.getAuthor(), 20),
                    b.getVolume());

            found = true;
        }
    }

    if (!found) {
        System.out.println("No comic book found with that title keyword.");
    }

    System.out.println(border);
}
 // 3) Search by author
    private void searchByAuthor(Scanner sc) {
        System.out.println("\n--- Search Book By Author ---");

        if (comicBooks.isEmpty()) {
            System.out.println("Inventory is empty.");
            return;
        }

        String query;
        while (true) {
            System.out.print("Enter author keyword: ");
            query = sc.nextLine().trim();
            if (!query.isEmpty()) break;
            System.out.println("ERROR: Search keyword cannot be empty.");
        }

        query = query.toLowerCase();

        boolean found = false;
        String border = "+------+--------+---------------------------+--------------+----------------------+--------+";

        System.out.println("\n--- SEARCH RESULT ---");
        System.out.println(border);
        System.out.printf("| %-4s | %-6s | %-25s | %-12s | %-20s | %-6s |%n",
                "No.", "ID", "Title", "RentalPrice", "Author", "Volume");
        System.out.println(border);

        int no = 1;
        for (ComicBooks b : comicBooks) {
            if (b.getAuthor().toLowerCase().contains(query)) {
                System.out.printf("| %4d | %6d | %-25s | %10.2f $ | %-20s | %6d |%n",
                        no++,
                        b.getId(),
                        cut(b.getTitle(), 25),
                        b.getBookRentalPrice(),
                        cut(b.getAuthor(), 20),
                        b.getVolume());
                found = true;
            }
        }

        if (!found) {
            System.out.println("No comic book found with that author keyword.");
        }
        System.out.println(border);
    }
 // 4) Update rental price by ID
    private void updateRentalPrice(Scanner sc) throws ComicBookException {
        System.out.println("\n--- Update Book Rental Price ---");

        if (comicBooks.isEmpty()) {
            System.out.println("Inventory is empty.");
            return;
        }

        int id = readInt(sc, "Enter ID to update price: ", 1, Integer.MAX_VALUE);
        int idx = findIndexById(id);

        if (idx == -1) {
            System.out.println("ERROR: No comic book found with ID " + id);
            return;
        }

        ComicBooks b = comicBooks.get(idx);
        System.out.println("Current book: " + b.getTitle() + " | Current price: " + String.format("%.2f", b.getBookRentalPrice()) + " $");

        double newPrice;
        while (true) {
            newPrice = readDouble(sc, "Enter new rental price (USD, must be > 0): ");
            if (newPrice <= 0) System.out.println("ERROR: Rental price must be greater than 0.");
            else break;
        }

        
        b.setBookRentalPrice(newPrice);
        System.out.println("SUCCESS: Rental price updated.");
    }
    // 5) Delete
    private void deleteById(Scanner sc) {
        System.out.println("\n--- Delete by ID ---");
        if (comicBooks.isEmpty()) {
            System.out.println("Inventory is empty.");
            return;
        }

        int id = readInt(sc, "Enter ID to delete: ", 1, Integer.MAX_VALUE);
        int idx = findIndexById(id);

        if (idx == -1) {
            System.out.println("ERROR: No comic book found with ID " + id);
            return;
        }

        comicBooks.remove(idx);
        System.out.println("SUCCESS: Comic book deleted.");
    }
    private String cut(String s, int max) {
    if (s == null) return "";
    if (s.length() <= max) return s;
    return s.substring(0, max - 3) + "...";
}

    // Display list (6 columns)
    private void displayInventory() {
    System.out.println("\n--- INVENTORY ---");

    if (comicBooks.isEmpty()) {
        System.out.println("(Empty)");
        return;
    }

    String border = "+------+--------+---------------------------+--------------+----------------------+--------+";

    System.out.println(border);
    System.out.printf("| %-4s | %-6s | %-25s | %-12s | %-20s | %-6s |%n",
            "No.", "ID", "Title", "RentalPrice", "Author", "Volume");
    System.out.println(border);

    int no = 1;
    for (ComicBooks b : comicBooks) {
        System.out.printf("| %4d | %6d | %-25s | %10.2f $ | %-20s | %6d |%n",
                no++,
                b.getId(),
                cut(b.getTitle(), 25),
                b.getBookRentalPrice(),
                cut(b.getAuthor(), 20),
                b.getVolume());
    }

    System.out.println(border);
}

    private String shorten(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(0, max - 3) + "...";
    }

    private int findIndexById(int id) {
        for (int i = 0; i < comicBooks.size(); i++) {
            if (comicBooks.get(i).getId() == id) return i;
        }
        return -1;
    }

    // Load file
    private void loadFromFile() {
        comicBooks.clear();

        if (!dataFile.exists()) {
            System.out.println("INFO: File still not found. Starting empty.");
            return;
        }

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(dataFile), StandardCharsets.UTF_8))) {

            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                ComicBooks b = ComicBooks.fromFileLine(line);
                if (b == null) continue;

                // unique by ID
                if (findIndexById(b.getId()) != -1) continue;

                // avoid duplicate content
                boolean dupContent = false;
                for (ComicBooks x : comicBooks) {
                    if (x.isSameContent(b)) {
                        dupContent = true;
                        break;
                    }
                }
                if (!dupContent) comicBooks.add(b);
            }

            System.out.println("INFO: Loaded " + comicBooks.size() + " comic book(s) from file.");
        } catch (Exception e) {
            System.out.println("WARNING: Failed to load file.");
        }
    }

    // Save file
    private void saveToFile() {
        try (BufferedWriter bw = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(dataFile), StandardCharsets.UTF_8))) {

            for (ComicBooks b : comicBooks) {
                bw.write(b.toFileLine());
                bw.newLine();
            }
        } catch (Exception e) {
            System.out.println("WARNING: Failed to save file.");
        }
    }

    // Validation input
    private int readInt(Scanner sc, String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String raw = sc.nextLine().trim();
            try {
                int val = Integer.parseInt(raw);
                if (val < min || val > max) {
                    System.out.println("ERROR: Value must be in [" + min + ", " + max + "].");
                    continue;
                }
                return val;
            } catch (NumberFormatException e) {
                System.out.println("ERROR: Please enter a valid integer.");
            }
        }
    }

    private double readDouble(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String raw = sc.nextLine().trim();
            try {
                double val = Double.parseDouble(raw);
                if (Double.isNaN(val) || Double.isInfinite(val)) {
                    System.out.println("ERROR: Invalid number.");
                    continue;
                }
                return val;
            } catch (NumberFormatException e) {
                System.out.println("ERROR: Please enter a valid decimal number (example: 12.5).");
            }
        }
    }

    private String readNonEmptyString(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = sc.nextLine();
            if (s != null && !s.trim().isEmpty()) return s.trim();
            System.out.println("ERROR: This field cannot be empty.");
        }
    }
}